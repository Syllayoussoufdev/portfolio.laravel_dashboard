<div class="container">
            <h2 class="section-title">Mes projets</h2>
            <div class="projects-grid">
                <?php if(auth()->guard()->check()): ?>         
                    <div class="mb-4 text-end">
                        <a href="<?php echo e(route('admin.projects.create')); ?>" class="btn btn-secondary">
                            <i class="bi bi-plus-lg"></i> Ajouter un Projet
                        </a>
                    </div>
                <?php endif; ?>
                <?php $__empty_1 = true; $__currentLoopData = $owner->projets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="project-card">
                        <div class="project-image">
                           
                            <?php if($projet->images && file_exists(public_path($projet->images))): ?>
                                <div class="project-image">
                                    <img src="<?php echo e(asset($projet->images)); ?>" alt="Image du projet <?php echo e($projet->nom); ?>">
                                </div> 
                            <?php else: ?>
                                
                                <div class="project-image">
                                    <?php
                                        // On normalise la catégorie pour la comparaison
                                        $category = strtolower($projet->category);
                                    ?>
                                    
                                    <?php if($category == 'web'): ?>
                                        <i class="fas fa-globe"></i>
                                    <?php elseif($category == 'mobile'): ?>
                                        <i class="fas fa-mobile-alt"></i>
                                    <?php elseif($category == 'ia' || $category == 'data'): ?>
                                        <i class="fas fa-brain"></i>
                                    <?php elseif($category == 'formation'): ?> 
                                        <i class="fas fa-graduation-cap"></i>
                                    <?php else: ?>
                                        <i class="fas fa-cubes"></i>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>                          
                        </div>
                        <div class="project-content">
                            <h3><?php echo e($projet->titre); ?></h3>
                            <h5>
                                <small class="text-muted">Catégorie : <?php echo e($projet->category); ?></small><br>
                                <small class="text-muted">Statut : "<?php echo e($projet->statut); ?>"</small>
                            </h5>
                            <p><?php echo e(Str::limit($projet->description, 120)); ?></p>
                            <div class="project-tech">
                                <?php $__empty_2 = true; $__currentLoopData = $projet->competence; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $competence): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?> 
                                    <span class="tech-tag"><?php echo e($competence->nom_competence); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                    <span class="tech-tag">Laravel,Bootstrap,MySQL</span>
                                <?php endif; ?>
                            </div>
                            <div class="project-buttons">
                                <?php if($projet->lien_demo
                                    ): ?>
                                    <a href="<?php echo e($projet->lien_demo); ?>" target="_blank" class="btn btn-primary">
                                        <i class="bi bi-eye"></i> En ligne
                                    </a>
                                <?php endif; ?>
                                <a href="<?php echo e(route('projects.show', $projet->id)); ?>" class="btn btn-small">
                                    Détails 
                                </a>
                                <?php if($projet->lien_github): ?>
                                    <a href="<?php echo e($projet->lien_github); ?>" target="_blank" class="btn btn-outline">
                                        <i class="bi bi-github"></i> GitHub
                                    </a>
                                <?php endif; ?>   
                                <br>
                                <?php if(auth()->guard()->check()): ?>
                                    <a href="<?php echo e(route('admin.projects.edit', $projet->id)); ?>" class="btn btn-warning btn-sm flex-grow-1">
                                        <i class="bi bi-pencil-square"></i> Éditer
                                    </a>
                                    <form action="<?php echo e(route('admin.projects.destroy', $projet->id)); ?>" method="POST" class="flex-grow-1">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm w-100" onclick="return confirm('Êtes-vous sûr de vouloir supprimer ce projet ?');">
                                            <i class="bi bi-trash"></i> Supprimer
                                        </button>
                                    </form>
                                <?php endif; ?>   
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>Aucun projet disponible.</p>
                <?php endif; ?>
            </div>
        </div>
<?php /**PATH /var/www/html/resources/views/partials/_projects.blade.php ENDPATH**/ ?>