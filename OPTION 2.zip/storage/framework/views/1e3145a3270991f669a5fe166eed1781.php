    <!-- Navigation fixe -->
    <nav class="navbar" id="navbar">
        <div class="nav-container">
            <div class="nav-logo">
                <a href="<?php echo e(route('home')); ?>">Sylla Y.</a>
            </div>
            <div class="nav-menu" id="nav-menu">
                <a href="<?php echo e(route('home')); ?>" class="nav-link active">Accueil</a>
                <a href="<?php echo e(route('home')); ?>/#apropos" class="nav-link">À propos</a>
                <a href="<?php echo e(route('home')); ?>/#competences" class="nav-link">Compétences</a>
                <a href="<?php echo e(route('home')); ?>/#projets" class="nav-link">Projets</a>
                <a href="<?php echo e(route('home')); ?>/#contact" class="nav-link">Contact</a>
                <?php if(auth()->guard()->check()): ?>
                    <a class="nav-link" href=<?php echo e(route('admin.Competences.index')); ?>>CRUD-Comp</a>
                    <a class="nav-link" href=<?php echo e(route('admin.diplomes.index')); ?>>CRUD-Diplômes / Certifications</a>
                    <a class="nav-link" href='#'>CRUD-Expériences</a>
                    <a class="nav-link" href=<?php echo e(route('admin.messages.index')); ?>>CRUD-Messages</a>        

                    <a href="<?php echo e(route('dashboard')); ?>" class="nav-link">Dashboard Administration</a>
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="nav-link">Logout</button>
                    </form>
                <?php else: ?>
                    
                <?php endif; ?>                        
            </div>
            <!-- Hamburger menu pour mobile -->
            <div class="nav-toggle" id="nav-toggle">
                <span class="bar"></span>
                <span class="bar"></span>
                <span class="bar"></span>
            </div>
        </div>
    </nav>
    <style src ="<?php echo e(asset('../assets/css/style2.css')); ?>">
    </style>n<?php /**PATH /var/www/html/resources/views/partials/navbar.blade.php ENDPATH**/ ?>