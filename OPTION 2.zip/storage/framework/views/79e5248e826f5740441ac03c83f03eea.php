<?php $__env->startSection('content'); ?>
    <!-- Section Accueil (Hero) -->
    <!-- HERO -->
    <section id="accueil" class="hero" aria-labelledby="hero-title">
        <div class="container hero-content">
        <div class="hero-image">
            <!-- Placeholder pour votre photo - remplacez par votre vraie photo -->
            <div class="profile-photo">
                <img src="<?php echo e(asset('assets/images/profil3.png')); ?>" alt="Photo de profil" />
            </div>
        </div>

        <div class="hero-right">
            <h1 id="hero-title" class="hero-title"><?php echo e($owner->name); ?></h1>
            <p class="hero-subtitle"><?php echo e($owner->titre_professionnel); ?></p>
            <p class="hero-description"><?php echo e($owner->biographie); ?></p>

            <div class="hero-buttons">
            <!-- lien direct vers ton CV (PDF) -->
            <a class="btn btn-primary" target="_blank" href="<?php echo e($owner->cv); ?>" download aria-label="Télécharger le CV de Sylla Youssouf">
                <i class="fas fa-download"></i> Télécharger mon CV
            </a>
            <a class="btn btn-secondary" href="#contact"><i class="fas fa-envelope"></i> Me contacter</a>
            </div>

            <!-- Skills quick badges -->
            <div class="quick-skills" aria-hidden="false">
            <span class="skill-badge">PHP</span>
            <span class="skill-badge">Laravel</span>
            <span class="skill-badge">MySQL</span>
            <span class="skill-badge">JavaScript</span>
            <span class="skill-badge">React</span>
            </div>
        </div>
        </div>
    </section>

    <!-- Section À propos -->
    <section id="apropos" class="about">
        <div class="container">
            <h2 class="section-title">À propos de moi</h2>
            <div class="about-content">
                <div class="about-text">
                    <p>
                        Jeune diplômé d'un BTS en Informatique Développeur d'Applications, j'ai travaillé sur plusieurs projets en PHP, Laravel, MySQL, HTML, CSS, JavaScript et Bootstrap. J'ai également une initiation en React.js et Flutter/Dart. Passionné par l'innovation digitale et les outils no-code, j'ai aussi une expérience en support technique, formation et documentation.
                    </p>
                    
                    <h3>Mon parcours</h3>
                    <div class="timeline">
                        <div class="timeline-item">
                            <div class="timeline-date">2025</div>
                            <div class="timeline-content">
                                <h4>Assistant technique - MUSCOP-CI : (Temp parciel)</h4>
                                <p>Support utilisateurs, formation, déploiement applicatif</p><br>

                                <h4>Freelance web - (Temp parciel)</h4>
                                <p>Propection et Realisatin de projet web en Freelance pas trop gros (site web, vibe coding, no-code, ect ...)</p>
                            </div>
                        </div>
                        <div class="timeline-item">
                            <div class="timeline-date">2023-2024</div>
                            <div class="timeline-content">
                                <h4>Stage développeur web - Stratos-CI</h4>
                                <p>PHP/Laravel, MySQL, Bootstrap, correction de bugs et documentation</p>
                            </div>
                        </div>
                        <div class="timeline-item">
                            <div class="timeline-date">2021-2023</div>
                            <div class="timeline-content">
                                <h4>BTS Informatique Développeur d'Applications</h4>
                                <p>ISFMI(Institut Supperieur de formation au Metier de l'Informatique) Abidjan - Diplôme et Soutenance</p>
                            </div>
                        </div>
                    </div>                    
                </div>
                
                <div class="about-cards">
                    <div class="info-card">
                        <i class="fas fa-map-marker-alt" aria-hidden="true"></i>
                            <h4>Localisation</h4>
                            <p>Abidjan, Côte d'Ivoire</p>
                        </div>
                            <div class="info-card">
                                <i class="fas fa-envelope" aria-hidden="true"></i>
                                <h4>Email</h4>
                                <p><a href="mailto:youssoufs1209@gmail.com">youssoufs1209@gmail.com</a></p>
                            </div>
                        <div class="info-card">
                            <i class="fab fa-github" aria-hidden="true"></i>
                            <h4>GitHub</h4>
                            <p><a href="https://github.com/Syllayoussoufdev" target="_blank" rel="noopener">Syllayoussoufdev</a></p>
                        </div>
                        <div class="info-card">
                            <i class="fab fa-linkedin" aria-hidden="true"></i>
                            <h4>LinkedIn</h4>
                            <p><a href="https://www.linkedin.com/in/sylla-youssouf-devweb?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app" target="_blank" rel="noopener">Sylla Youssouf</a></p>
                        </div>
                </div>
            </div>
        </div>
    </section>
        
    <!-- Section Compétences -->
    <section id="competences" class="skills">
        <div class="container">
            <h2 class="section-title">Mes compétences</h2>
            <div class="skills-grid">

                <!-- Frontend Skills -->
                    <div class="skill-category">
                        <h3><i class="fas fa-palette"></i> Frontend</h3>
                            <div class="skill-list">
                            <?php $__currentLoopData = $owner->competences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $competence): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>          
                                <?php if($competence->type === 'Front-end'): ?>
                                        <div class="skill-item">
                                            <div class="skill-info">
                                                <span><?php echo e($competence->nom_competence); ?></span>
                                                <span><?php echo e($competence->niveau); ?></span>
                                                <span><?php echo e($competence->pourcentage); ?></span>
                                            </div>
                                            <div class="skill-bar">
                                                <div class="skill-progress" data-width="<?php echo e($competence->pourcentage); ?>%"></div>
                                            </div>
                                        </div>
                                <?php endif; ?>                          
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>              
                    </div>

                <!-- Backend Skills -->
                <div class="skill-category">
                    <h3><i class="fas fa-server"></i> Backend</h3>
                            <div class="skill-list">
                                <?php $__currentLoopData = $owner->competences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $competence): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>          
                                    <?php if($competence->type === 'Back-end'): ?>
                                            <div class="skill-item">
                                                <div class="skill-info">
                                                    <span><?php echo e($competence->nom_competence); ?></span>
                                                    <span><?php echo e($competence->niveau); ?></span>
                                                    <span><?php echo e($competence->pourcentage); ?></span>
                                                </div>
                                                <div class="skill-bar">
                                                    <div class="skill-progress" data-width="<?php echo e($competence->pourcentage); ?>%"></div>
                                                </div>
                                            </div>
                                    <?php endif; ?>                          
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                </div>

                <!-- Mobile & Outils -->
                <div class="skill-category">
                    <h3><i class="fas fa-mobile-alt"></i> Autre</h3>
                    <div class="skill-list">
                        <?php $__currentLoopData = $owner->competences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $competence): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>          
                            <?php if($competence->type === 'Autre'): ?>
                                    <div class="skill-item">
                                        <div class="skill-info">
                                            <span><?php echo e($competence->nom_competence); ?></span>
                                            <span><?php echo e($competence->niveau); ?></span>
                                            <span><?php echo e($competence->pourcentage); ?></span>
                                        </div>
                                        <div class="skill-bar">
                                            <div class="skill-progress" data-width="<?php echo e($competence->pourcentage); ?>%"></div>
                                        </div>
                                    </div>
                            <?php endif; ?>                          
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Section Formations & Certificats -->
    <section id="apropos" class="about">
        <div class="container">
            <h2 class="section-title">Formations & Certificats </h2>
            <div class="about-content">
                <div class="about-text">
                    <div class="timeline">                        
                        <?php $__currentLoopData = $certificats_grouped; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year => $certificats): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="timeline-item">
                            <div class="timeline-date"><?php echo e($year); ?></div>
                            <div class="timeline-content">
                                <?php $__currentLoopData = $certificats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certificat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <h4><?php echo e($certificat->nom_diplome); ?></h4>
                                    <p><?php echo e($certificat->centre_formateur); ?></p><br>
                                    <p><?php echo e($certificat->description); ?></p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>  
                </div>                    
            </div>
        </div>
    </section>

    <!-- Section Projets -->
    <section id="projets" class="projects">
        <?php echo $__env->make('partials._projects', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </section>

    <!-- Section Contact -->
    <section id="contact" class="contact">
        <?php echo $__env->make('partials._contact_form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </section>
    <!-- Script JavaScript -->
    <script src=<?php echo e(asset('assets/js/script2.js')); ?>></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.portfolio_template', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/portfolio/Home.blade.php ENDPATH**/ ?>