<!-- Footer -->
    <footer class="footer">
        <div class="container">
            <p>&copy; 2025 Sylla Youssouf. Tous droits réservés.</p>
             <p>Développé à Abidjan</p>
            
             
        </div> 
        
    </footer><?php /**PATH /var/www/html/resources/views/partials/footer.blade.php ENDPATH**/ ?>