<!DOCTYPE html>
<html lang="en">
    <?php echo $__env->make('partials.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <body>
    <!-- Inclure la barre de navigation (un partial) -->
    <?php echo $__env->make('partials.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <h1 class="text-center mt-4">views admin</h1>

    <!-- Zone de contenu principale -->
        <?php echo $__env->yieldContent('content'); ?>
    

    <!-- Inclure le footer (un partial) -->
    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Vos scripts JS globaux -->
    <script src="<?php echo e(asset('../assets/js/script1.js')); ?>"></script>

    </body>
</html><?php /**PATH /var/www/html/resources/views/layouts/portfolio_template.blade.php ENDPATH**/ ?>